import sqlite3 as sql 
import pandas as pd
database = 'STAFF.db' 
table_name = 'INSTRUCTOR'
attribute_list = ['ID', 'FNAME', 'LNAME', 'CITY', 'CCODE']
file_path = '/home/project/INSTRUCTOR.csv'
df = pd.read_csv(file_path, names = attribute_list)
print("CSV TO DATAFRAME")
print(df)
print("LOADING DATAFRAME TO THE DB") 
conn = sql.connect(database)
df.to_sql(table_name, conn, if_exists = 'replace', index=False)
print("Table is ready")
#Running queries
query_statement = f"SELECT * FROM {table_name}"
query_output = pd.read_sql(query_statement, conn)
print(query_statement)
print(query_output)
print('------------------------------------------------------------')
query_statement= f"SELECT FNAME FROM {table_name}"
query_output = pd.read_sql(query_statement, conn)
print(query_statement)
print(query_output)
print('------------------------------------------------------------')
query_statement = f"SELECT COUNT(*) FROM {table_name}"
query_output = pd.read_sql(query_statement, conn)
print(query_statement)
print(query_output)
print('------------------------------------------------------------')
data_dict = {'ID': [100], 
              'FNAME': ['JOHN'],
              'LNAME': ['DOE'],
              'CITY': ['PARIS'],
              'CCODE':['FR']}
data_append = pd.DataFrame(data_dict)

data_append.to_sql(table_name, conn, if_exists = 'append', index=False)
print('Data appended successfully')
table_output = pd.read_sql(f'SELECT * FROM {table_name}', conn)
print(table_output)
conn.close

#Practice Problems 
table_Dpm = "DEPARTMENTS"
attribute_dpm = ['DEPT_ID', 'DEP_NAME', 'MANAGER_ID', 'LOC_ID']
file_path_dep = '/home/project/Departments.csv'
df2 = pd.read_csv(file_path_dep, names = attribute_dpm)
print(df2)
df2.to_sql(table_Dpm, conn, if_exists = 'replace', index=False)
table_output_dpm = pd.read_sql(f'SELECT * FROM {table_Dpm}', conn)
print(table_output_dpm)
#Queries
print('Queries')
query_va= f'SELECT *FROM {table_Dpm}'
query_output_va = pd.read_sql(query_va, conn)
print(query_output_va)
print('------------------------------------------------------------')
query_vDN= f'SELECT DEP_NAME FROM {table_Dpm}'
query_output_vDN = pd.read_sql(query_vDN, conn)
print(query_output_vDN)
print('------------------------------------------------------------')
query_COUNT= f'SELECT COUNT(*) FROM {table_Dpm}'
query_output_COUNT = pd.read_sql(query_COUNT, conn)
print(query_output_COUNT)
print('------------------------------------------------------------')
conn.close